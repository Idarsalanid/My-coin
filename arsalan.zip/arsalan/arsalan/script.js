const music = document.getElementById("bg-music");
const muteBtn = document.getElementById("mute-btn");

// پخش موزیک پس از کلیک
window.addEventListener("click", () => {
  if (music.paused) {
    music.play().catch(() => {
      console.log("پخش نشد - محدودیت مرورگر");
    });
  }
});

muteBtn.addEventListener("click", (e) => {
  e.stopPropagation();
  music.muted = !music.muted;
  muteBtn.textContent = music.muted ? "🔇" : "🔊";
});

// درباره من
const infoBtn = document.getElementById("info-btn");
const infoBox = document.getElementById("info-box");
const closeInfo = document.getElementById("close-info");

infoBtn.addEventListener("click", (e) => {
  e.stopPropagation();
  infoBox.classList.add("show");
});

closeInfo.addEventListener("click", () => {
  infoBox.classList.remove("show");
});

// بازی کوین
const coinBtn = document.getElementById("coin-btn");
const coinBox = document.getElementById("coin-box");
const closeCoin = document.getElementById("close-coin");
const coinCount = document.querySelector(".coin-count");
const coinImg = document.getElementById("coin-img");
const coinSound1 = document.getElementById("coin-sound1");
const coinSound2 = document.getElementById("coin-sound2");

// اضافه کردن دکمه پاک کردن تاریخچه کوین‌ها
const clearHistoryBtn = document.createElement("button");
clearHistoryBtn.textContent = "پاک کردن تاریخچه";
clearHistoryBtn.style.marginTop = "15px";
clearHistoryBtn.style.padding = "10px";
clearHistoryBtn.style.width = "100%";
clearHistoryBtn.style.fontSize = "1em";
clearHistoryBtn.style.borderRadius = "10px";
clearHistoryBtn.style.cursor = "pointer";
clearHistoryBtn.style.border = "none";
clearHistoryBtn.style.backgroundColor = "rgba(255, 255, 255, 0.2)";
clearHistoryBtn.style.color = "white";
clearHistoryBtn.style.backdropFilter = "blur(6px)";
clearHistoryBtn.addEventListener("mouseenter", () => {
  clearHistoryBtn.style.backgroundColor = "rgba(255, 255, 255, 0.35)";
});
clearHistoryBtn.addEventListener("mouseleave", () => {
  clearHistoryBtn.style.backgroundColor = "rgba(255, 255, 255, 0.2)";
});
coinBox.appendChild(clearHistoryBtn);

let coins = 0;
let soundToggle = false;

// بازی رو وقتی باز میشه مقدار کوین رو از localStorage بارگذاری کن
coinBtn.addEventListener("click", () => {
  coinBox.classList.add("show");
  coins = parseInt(localStorage.getItem("coins")) || 0;
  coinCount.textContent = coins.toLocaleString("fa-IR");
});

// بستن پنجره بازی
closeCoin.addEventListener("click", () => {
  coinBox.classList.remove("show");
});

// پاک کردن تاریخچه کوین‌ها
clearHistoryBtn.addEventListener("click", () => {
  coins = 0;
  localStorage.setItem("coins", coins);
  coinCount.textContent = coins.toLocaleString("fa-IR");
});

// تابع ایجاد انیمیشن +10
function showPlusTenAnimation() {
  const container = coinImg.parentElement;
  const plusTen = document.createElement("div");
  plusTen.textContent = "+10";
  plusTen.classList.add("plus-ten-animation");

  // موقعیت به نسبت container (که relative است)
  const rect = coinImg.getBoundingClientRect();
  const containerRect = container.getBoundingClientRect();

  plusTen.style.left = (rect.left - containerRect.left + rect.width / 2 - 15) + "px";
  plusTen.style.top = (rect.top - containerRect.top - 30) + "px";

  container.appendChild(plusTen);

  setTimeout(() => {
    plusTen.remove();
  }, 1000);
}

coinImg.addEventListener("click", () => {
  coins += 10;
  coinCount.textContent = coins.toLocaleString("fa-IR");
  localStorage.setItem("coins", coins);

  if (soundToggle) {
    coinSound1.currentTime = 0;
    coinSound1.play();
  } else {
    coinSound2.currentTime = 0;
    coinSound2.play();
  }
  soundToggle = !soundToggle;

  showPlusTenAnimation();
});